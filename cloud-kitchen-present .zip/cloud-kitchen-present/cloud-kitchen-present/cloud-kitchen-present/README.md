# CloudKitchen — Presentation-ready Frontend

Run `npm install` then `npm run dev`.

To replace images, put them in public/images and update src/data/mock.js or use absolute paths.
